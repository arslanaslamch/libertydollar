import { Request, Response, NextFunction } from 'express';
import { MySessionData } from '../partials/usersession';
import * as mysql from 'mysql2/promise';

const dbConfig = {
  host: '104.255.172.50',
  user: 'ldfa_debug',
  password: 'ldfa_debug',
  database: 'ldfa_debug',
};


const pool = mysql.createPool(dbConfig);
export const fetchTableNamesMiddleware = async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Change 'dev_messages_' to the actual prefix you're looking for
      const prefix = 'dev_messages_';
  
      // Query to get tables with a specific prefix
      const query = `
        SHOW TABLES
        LIKE '${prefix}%'
      `;
        const [result] = await pool.query(query);
        const tables = result.map((row: any) => {
        const tableName = Object.values(row)[0];
        return tableName.substring(prefix.length);
      });
      res.locals.tables = tables;

      next();
    } catch (error) {
      console.error('Error retrieving table list:', error);
      res.status(500).send('Internal Server Error');
      res.locals.tables = []; // Set an empty array in case of an error
      next();
    }
  };
  

  