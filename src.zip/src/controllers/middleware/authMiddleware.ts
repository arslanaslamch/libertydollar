import { Request, Response, NextFunction } from 'express';
import { MySessionData } from '../partials/usersession';
import * as mysql from 'mysql2/promise';

const dbConfig = {
  host: '104.255.172.50',
  user: 'ldfa_debug',
  password: 'ldfa_debug',
  database: 'ldfa_debug',
};


const pool = mysql.createPool(dbConfig);

export const authMiddleware = async (req: Request<MySessionData>, res: Response, next: NextFunction) => {
  try {
    if (req.session.user) {
      const [rows] = await pool.execute('SELECT * FROM users WHERE username = ?', [req.session.user]);

      if (Array.isArray(rows) && rows.length > 0) {
        req.user = rows[0];
        res.locals.user = rows[0];
      }
    }
    next();
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
};