import { Request, Response } from 'express';
import * as mysql from 'mysql2/promise';
import * as session from 'express-session';
import { MySessionData } from './partials/usersession';




const dbConfig = {
    host: '104.255.172.50',
    user: 'ldfa_debug',
    password: 'ldfa_debug',
    database: 'ldfa_debug',
  };
  
const pool = mysql.createPool(dbConfig);


export const ClientBugs = async (req: Request, res: Response) => {
    if (req.user) {
        const slug = req.params.slug;
        const tableName = "dev_messages_" + slug;

        try {
            const connection = await pool.getConnection();
            const [rows] = await connection.query(`SELECT * FROM \`${tableName}\``);
            const [userDatas] = await connection.query(`SELECT * FROM members`);
            connection.release();
            res.render('bugs', { data: rows, slug: slug, userData: userDatas });
        } catch (error) {
            console.error(error);
            res.status(500).showToast(error.message, 'danger');            ;
        }
    }else{
        res.redirect('/');
    }
}
export const deleteBug = async (req: Request, res: Response) => {
    if (req.user) {
        const slug = req.params.slug;
        const tableName = "dev_messages_" + slug;
        const recordID = req.params.id;
        try {
            const connection = await pool.getConnection();
            const [rows] = await connection.query(`DELETE FROM \`${tableName}\` WHERE id=?`, [recordID]);
            connection.release();
            res.redirect('back');
        } catch (error) {
            res.redirect('back');         ;
        }
    }else{
        res.redirect('/');
    }
}

export const resolvedBug = async (req: Request, res: Response) => {
    if (req.user) {
        const slug = req.params.slug;
        const tableName = "dev_messages_" + slug;
        const recordID = req.params.id;
        const UserID = req.user.id;
        try {
            const connection = await pool.getConnection();
            const [rows] = await connection.query(`UPDATE \`${tableName}\` SET resolved_by=?, resolution=?, resolved_at=NOW() WHERE id=?`, [UserID, 'Hello User', recordID]);
            connection.release();
            res.redirect('back');
        } catch (error) {
            res.redirect('back');         ;
        }
    }else{
        res.redirect('/');
    }
}

export const viewBug = async (req: Request, res: Response) => {
    if (req.user) {
        const slug = req.params.slug;
        const tableName = "dev_messages_" + slug;
        const recordID = req.params.id;
        const UserID = req.user.id;
        try {
            const connection = await pool.getConnection();
            const [rows] = await connection.query(`SELECT * FROM \`${tableName}\` WHERE id=? LIMIT 1`, [recordID]);

            // Check if rows is defined and not empty before accessing user_id
            if (rows && rows.length > 0) {
                const userSID = rows[0].user_id;  // Corrected this line
                const [userData] = await connection.query(`SELECT * FROM members`);
                connection.release();
                
                res.render('view-bugs', { data: rows, slug: slug, userData: userData });
            } else {
                // Handle the case when no rows are found
                connection.release();
                res.redirect('back');
            }
        } catch (error) {
            console.error('Error fetching data:', error);
            res.redirect('back');
        }
    } else {
        res.redirect('/');
    }
}

export const viewUsersList = async (req: Request, res: Response) => {
    if (req.user) {
        try {
            const connection = await pool.getConnection();
            const [rows] = await connection.query(`SELECT * FROM users`);
            connection.release();
            res.render('view-all-users', { data: rows });
        } catch (error) {
            console.error(error);
            res.status(500).showToast(error.message, 'danger');            ;
        }
    }else{
        res.redirect('/');
    }
}
export const ChangePassword = async (req: Request, res: Response) => {
    if (req.user) {
        try {
            const userID = req.params.id;
            res.render('change-password', { userID: userID });
        } catch (error) {
            console.error(error);
            res.status(500).showToast(error.message, 'danger');            ;
        }
    }else{
        res.redirect('/');
    }
}