import { Request, Response } from 'express';
import * as mysql from 'mysql2/promise';
import * as session from 'express-session';
import { MySessionData } from './partials/usersession';
import * as toastr from 'toastr';
import Swal from 'sweetalert';
import bcrypt from 'bcrypt';


const dbConfig = {
  host: '104.255.172.50',
  user: 'ldfa_debug',
  password: 'ldfa_debug',
  database: 'ldfa_debug',
};

const pool = mysql.createPool(dbConfig);

export const login = async (req: Request, res: Response) => {
  const { username, password } = req.body;

  try {
    const [rows] = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);

    if (rows.length > 0) {
      const storedHashedPassword = rows[0].password; // Assuming your password field is named 'password' in the database
      const passwordMatch = await bcrypt.compare(password, storedHashedPassword);

      if (passwordMatch) {
        // Set up a session
        (req.session as MySessionData).user = username;
        res.json({ success: true });
      } else {
        res.status(401).json({ success: false, error: 'Login Failed' });
      }
    } else {
      res.status(401).json({ success: false, error: 'Login Failed' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
};

export const logout = (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    } else {
      res.redirect('/');
    }
  });
};

export const dashboard = (req: Request<MySessionData>, res: Response) => {
  if (req.user) {
    res.render('dashboard');
  } else {
    res.redirect('/');
  }
};
