import { Session, SessionData } from 'express-session';

interface MySessionData extends Session {
  user?: string;
}

export { MySessionData };