// express.d.ts

import { MySessionData } from './usersession';
import { Request } from 'express';

declare module 'express-serve-static-core' {
  interface Request<P = Record<string, any>> {
    user?: MySessionData;
  }
}
