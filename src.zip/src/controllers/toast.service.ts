import Swal from 'sweetalert2';
import toastr from 'toastr';

class ToastService {
  showSuccessToast(message: string) {
    toastr.success(message);
  }

  showErrorToast(message: string) {
    toastr.error(message);
  }

  showInfoToast(message: string) {
    toastr.info(message);
  }

  showWarningToast(message: string) {
    toastr.warning(message);
  }

  showToast(message: string, type: 'success' | 'error' | 'info' | 'warning' = 'success') {
    toastr[type](message);
  }

  showSweetAlertToast(message: string, type: 'success' | 'error' | 'info' | 'warning' = 'success') {
    Swal.fire({
      title: message,
      icon: type,
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
    });
  }
}

export const toastService = new ToastService();
