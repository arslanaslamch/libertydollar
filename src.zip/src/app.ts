// src/app.ts

import express, { Request, Response } from 'express';
import session from 'express-session';
import * as path from 'path';
import { login, logout, dashboard } from './controllers/authController';
import { authMiddleware } from './controllers/middleware/authMiddleware';
import { ClientBugs, deleteBug, resolvedBug, viewBug, viewUsersList, ChangePassword } from './controllers/dataController';
import { fetchTableNamesMiddleware } from './controllers/middleware/tablesMiddleware';
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, '../public')));
app.use('/css', express.static(path.join(__dirname, '../public', 'css'), { 'Content-Type': 'text/css' }));
app.use('/js', express.static(path.join(__dirname, '../public', 'js'), { 'Content-Type': 'application/javascript' }));


// Middleware
app.use(express.urlencoded({ extended: true }));


app.use(
  session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
  })
);

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(authMiddleware);
app.use(fetchTableNamesMiddleware);

// Routes 

app.get('/', (req: Request, res: Response) => { if(req.user){ res.redirect('dashboard') } else { res.render('login') } });
app.post('/login', login);
app.get('/logout', logout);
app.get('/dashboard', dashboard);
app.get('/bugs-:slug/', ClientBugs);
app.get('/delete-bug/:slug/:id', deleteBug);
app.get('/resolved-bug/:slug/:id', resolvedBug);
app.get('/view-bug-:slug-:id', viewBug)
app.get('/all-users', viewUsersList)
app.get('/change-password-:id', ChangePassword);
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
