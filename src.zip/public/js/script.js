

$(document).ready(function() {
    $('#loginForm').submit(function(e) {
      e.preventDefault();
      var formData = $(this).serialize();
      $.ajax({
        type: 'POST', 
        url: '/login',
        data: formData,
        success: function(response) {
          window.location.href = "/dashboard";
        },
        error: function(error) {
          console.error('Error:', error);
        }
      });
    });
});
